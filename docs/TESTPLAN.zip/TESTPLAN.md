# poly_mul test plan

DUT is [`rtl/poly_mul.sv`](../rtl/poly_mul.sv): streamed multiplication in \(Z_{3329}[x]/(x^{256}+1)\).

```mermaid
flowchart LR
  xIn[x stream] --> fwdX[forward NTT]
  yIn[y stream] --> fwdY[forward NTT or bypass]
  fwdX --> pmul[basemul]
  fwdY --> pmul
  pmul --> intt[inverse NTT]
  intt --> scale[scale by 3303]
  scale --> outP[output stream]
```

Each beat carries `2 * NUM_BUTFLY_PER_STAGE` coefficients, taken as pairs from the low and high halves of the polynomial. Seven NTT stages (Kyber, not a full 8-stage NTT) feed a degree-1 basemul, then inverse NTT and the constant scale. `downstream_ready` low freezes the whole pipe; `NTT_ready` tells the producer to hold its inputs.

Reference is the same negacyclic convolution already in [`testbench/tb_poly_mul_rand.sv`](../testbench/tb_poly_mul_rand.sv): schoolbook product reduced mod \(x^{256}+1\) and mod 3329. Compare coefficients in order. The current TB sorts both sides before comparing, so a permutation of a correct product still passes; ordered compare is the pass rule for this plan.

## Configs

Sweep the four legal widths and both y paths. `NUM_BUTFLY_PER_STAGE` outside `{1, 2, 4, 8}` is not a supported config.

- Butterfly width 1, 2, 4, 8
- `SKIP_Y_FWD_NTT=0`: both inputs in coefficient domain, driven together
- `SKIP_Y_FWD_NTT=1`: y already in the NTT domain and aligned with the x forward-NTT output

## Tests

**Function**

- Random polynomials in `[0, 3328]`, several back-to-back and with idle gaps between them. Every coefficient of every product matches the reference, in order, and the output count equals the input count.
- Directed pairs: both zero; one zero; single coefficient 1 (the unit); all coefficients `q-1`; one coefficient nonzero in x and in y. These hit the scale, the ring wrap `x^256 = -1`, and the basemul gamma path.
- Same pair repeated, and x*y versus y*x, to check the pipe drains and that the ring product is commutative.

**Handshake**

- `downstream_ready` tied high (baseline).
- Random ready, including a stall on the first output beat, a stall on the last beat of a polynomial, and a stall longer than the multiplier pipeline. While stalled, `output_poly` must not change and `NTT_ready` must stay low. After ready returns, the held beat is accepted once and the remaining coefficients match the reference.
- Idle gaps only between polynomials. A bubble in the middle of a polynomial is not part of the streaming contract this pipe implements.

**Reset**

- Reset held through the first few cycles, then released with inputs idle. No valid output before the first full polynomial has been accepted.
- Assert reset mid-polynomial and during a stall. After release, a new pair produces the reference product and no partial polynomial from before reset is emitted.

## Pass and existing runs

A test passes when the ordered product matches, the output count matches, and the stall-hold check reports zero violations.

[`make sanity`](../Makefile) and [`make sanity_bp`](../Makefile) already run the random TB across butterfly width and y-bypass, with and without backpressure. They do not enforce coefficient order, directed corners, or mid-stream reset. SpyGlass lint (`make lint`) stays a separate, non-functional check.
